---
layout: home
title: Macro Mentor
---

Welcome to **Macro Mentor** — evidence-based macros, meal prep, and efficient lifting.
